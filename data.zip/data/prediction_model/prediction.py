import os
import pandas as pd
from joblib import load
import numpy as np

# 用户配置：模型路径列表 & 对应权重
model_paths = []

for i in range(0, 5):
    path = os.path.join("xxxxxx\\"f'logic_model_{i}.pkl')
    model_paths.append(path)

# 检查权重归一化
weights = [0.2] * 5 # 每个模型的权重都是0.2（总和为1）

# 加载新数据（无标签）
data = pd.read_csv(r'xxxxxx\xxx.csv')

stella_features = data.iloc[:, :]

# stella_features = data.iloc[:, 2:]
# id = data.iloc[:, 0]
# kic = data.iloc[:, 1]
# 对每个模型计算预测概率
proba_list = []
for path in model_paths:
    if not os.path.exists(path):
        raise FileNotFoundError(f"模型文件不存在：{path}")
    model = load(path)
    print(model)
    proba = model.predict_proba(stella_features)[:, 1]  # 取正类概率
    proba_list.append(proba)

# 转成二维数组：shape = (n_models, n_samples)
proba_arr = np.vstack(proba_list)

# 按权重加权平均
weighted_proba = np.dot(weights, proba_arr)

# 设定阈值（threshold），默认 0.5
threshold = 0.5
y_pred = (weighted_proba >= threshold).astype(int)

# 构造只包含预测结果的 DataFrame
output_df = pd.DataFrame({
    # 'id': id,
    # 'kic': kic,
    'y_pred': y_pred,
    'pred_proba': weighted_proba
})
output_df.to_csv(r'xxxxxx\xxx.csv', index=False)

print("加权投票完成，结果已保存")